﻿using System;
using System.Collections.Generic;

namespace DataStructure_Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-------------- Array Example --------------");
            ArrayExample();

            Console.WriteLine("-------------- Linked List Example -------------");
            LinkedListExample();
        }

        private static void LinkedListExample()
        {
            LinkedList<int> linkedList = new LinkedList<int>();

            linkedList.AddLast(1);
            linkedList.AddLast(2);
            linkedList.AddLast(3);
            linkedList.AddLast(4);
            linkedList.AddLast(5);

            var node = linkedList.First;
            for (int i = 0; i < 2; i++)
            {
                node = node?.Next;
            }
            Console.WriteLine("Accessing third element in linked list: " + node?.Value);

            linkedList.AddLast(6);

            Console.WriteLine("Linked list after adding an element: ");
            foreach (var item in linkedList)
            {
                Console.Write(item + " ");
            }
        }

        private static void ArrayExample()
        {
            int[] array = new int[5] { 1, 2, 3, 4, 5 };

            Console.WriteLine("Accessing element at index 2 in array: " + array[2]);


            int[] newArray = new int[6];
            Array.Copy(array, newArray, array.Length);
            newArray[5] = 6;

            Console.WriteLine("New array with added element: " + string.Join(", ", newArray));
        }
    }
}
