﻿using System;
using System.Text;

namespace DataStructure_Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder("This is to test whether the extension method count can return a right answer or not");

            int wordCount = sb.WordCount();

            Console.WriteLine("Number of words in StringBuilder: " + wordCount);
        }
    }
}
