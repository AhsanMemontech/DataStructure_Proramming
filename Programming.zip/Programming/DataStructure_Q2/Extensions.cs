﻿using System.Text;

namespace DataStructure_Q2
{
    public static class Extensions
    {
        public static int WordCount(this StringBuilder sb)
        {
            string content = sb.ToString();

            string[] words = content.Split(new char[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            return words.Length;
        }
    }
}
