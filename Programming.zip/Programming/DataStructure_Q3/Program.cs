﻿using System;
using System.Collections.Generic;
using System.IO;
using static DataStructure_Q3.Medalist;

namespace DataStructure_Q3
{
    class Program
    {
        static List<Medalist> medalists = new List<Medalist>();

        static void Main(string[] args)
        {
            LoadData("Medals.csv");
            DisplayMedalists();

            AddMedalist(new Medalist("John Doe", 2024, 3, 1, 2));

            DeleteMedalist("John Doe");

            SearchForMedalistByAthlete("Michael Phelps");

            SearchForMedalistByYear(2000);

            SortMedalistsByYear();
        }

        static void LoadData(string fileName)
        {
            string[] lines = File.ReadAllLines(fileName);
            for (int i = 1; i < lines.Length; i++)
            {
                var fields = lines[i].Split(',');
                Medalist medalist = new Medalist(
                    fields[0],
                    int.Parse(fields[1]),
                    int.Parse(fields[2]),
                    int.Parse(fields[3]),
                    int.Parse(fields[4])
                );
                medalists.Add(medalist);
            }
        }

        static void DisplayMedalists()
        {
            foreach (var medalist in medalists)
            {
                Console.WriteLine(medalist);
            }
        }

        static void AddMedalist(Medalist newMedalist)
        {
            medalists.Add(newMedalist);
            DisplayMedalists();
        }

        static void DeleteMedalist(string athleteName)
        {
            medalists.RemoveAll(m => m.Athlete.Equals(athleteName, StringComparison.OrdinalIgnoreCase));
            DisplayMedalists();
        }

        static IEnumerable<T> Search<T>(Func<T, bool> searchCriteria, List<T> collection)
        {
            foreach (var item in collection)
            {
                if (searchCriteria(item))
                {
                    yield return item;
                }
            }
        }

        static void SearchForMedalistByAthlete(string athlete)
        {
            var results = Search(m => m.Athlete.Equals(athlete, StringComparison.OrdinalIgnoreCase), medalists);
            foreach (var result in results)
            {
                Console.WriteLine(result);
            }
        }

        static void SearchForMedalistByYear(int year)
        {
            var results = Search(m => m.Year == year, medalists);
            foreach (var result in results)
            {
                Console.WriteLine(result);
            }
        }

        static void SortMedalistsByYear()
        {
            medalists.Sort(new MedalistComparer());
            DisplayMedalists();
        }
    }
}
