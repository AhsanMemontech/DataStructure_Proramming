﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStructure_Q3
{
    public class Medalist
    {
        public string Athlete { get; set; }
        public int Year { get; set; }
        public int GoldMedals { get; set; }
        public int SilverMedals { get; set; }
        public int BronzeMedals { get; set; }

        public Medalist(string athlete, int year, int goldMedals, int silverMedals, int bronzeMedals)
        {
            Athlete = athlete;
            Year = year;
            GoldMedals = goldMedals;
            SilverMedals = silverMedals;
            BronzeMedals = bronzeMedals;
        }

        public override string ToString()
        {
            return $"{Athlete} ({Year}) - Gold: {GoldMedals}, Silver: {SilverMedals}, Bronze: {BronzeMedals}";
        }

        public class MedalistComparer : IComparer<Medalist>
        {
            public int Compare(Medalist x, Medalist y)
            {
                return x.Year.CompareTo(y.Year);
            }
        }
    }
}

